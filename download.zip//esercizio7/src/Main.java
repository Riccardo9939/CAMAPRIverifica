import java.util.*;

public class Main {

    public static void main(String[] args) {
        String s1 = null;
        String s2 = null;
        String s3 = null;
	    Scanner scan = new Scanner(System.in);
	    System.out.println("Inserisci il tuo nome:");
	    s1 = scan.nextLine();
	    if (s1.equals("")){
	       System.out.println("Devi inserire tutti i dati !");
	    }else{
	    System.out.println("Inserisci il tuo cognome:");
	    s2 = scan.nextLine();
	    if (s2.equals("")){
	       System.out.println("Devi inserire tutti i dati !");
	    }else{
	    System.out.println("Inserisci la tua lingua: IT/EN/FR/DE/ES");
	    s3 = scan.nextLine();
	    if (s3.equals("")){
	       System.out.println("Devi inserire tutti i dati !");
	    }else{
	    if (s3.equals("IT")){
	        System.out.println("Benvenuto "+s1+" "+s2);
	    }else if (s3.equals("EN")){
	        System.out.println("Welcome "+s1+" "+s2);
	    }else if (s3.equals("FR")){
	        System.out.println("Vienvenue "+s1+" "+s2);
	    }else if (s3.equals("DE")){
	        System.out.println("Willkommen "+s1+" "+s2);
	    }else if (s3.equals("ES")){
	        System.out.println("Bienvenida "+s1+" "+s2);
	    }else{System.out.println("Il sistema non parla questa lingua.");}}}}
	    scan.close();
    }
    
}