import java.util.*;

public class Main {

    public static void main(String[] args) {
	    Scanner scan = new Scanner(System.in);
	    System.out.println("Inserisci il tuo nome!");
	    String a = scan.nextLine();
	    System.out.println("Inserisci il tuo cognome!");
	    String b = scan.nextLine();
	    System.out.println("Inserisci la lingua tra inglese, francese, spagnolo, tedesco o italiano.");
	    String c = scan.nextLine();

    
    if (a.equals("") && b.equals("") && c.equals("")){
          	   if(c.equals("inglese")){
	    System.out.println("Hello " + a  + " " + b);
    }
    else if(c.equals("francese")){
	    System.out.println("Bounjour " + a  + " " + b);
    }
    else if(c.equals("spagnolo")){
	    System.out.println("Hola " + a  + " " + b);
    }
    else if(c.equals("tedesco")){
	    System.out.println("Gutenmorgen " + a  + " " + b);
    }
    else if(c.equals("italiano")){
	    System.out.println("Buongiorno " + a  + " " + b);
    }
    else{
        System.out.println("Non parlo la tua lingua");
    }
      } 
	   if (a.equals("") && b.equals("") && c.equals("")){
	       
    }
    else
      {
           System.out.println("manca qualcosa");
         
      
      }
 }
}