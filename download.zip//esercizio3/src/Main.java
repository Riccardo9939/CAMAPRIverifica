import java.util.Scanner;




public class Main {
    public static void main(String[] args) {
	   
	    Scanner scan = new Scanner(System.in);
	  
	    System.out.println("Numero da elevare!");
	     int a = scan.nextInt();
	     
	     System.out.println("inserisci la potenza!");
	     int b = scan.nextInt();
	     if (a > 0 && a < 10 && b > 0 && b < 10 ){
	         
	     
	     
	    double c = Math.pow (a, b);
	    System.out.println("il riusltato è!" + c);
	    scan.close();
    }
          else {
             System.out.println("errore"); 
          }
    }

}
