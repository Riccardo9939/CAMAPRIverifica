import java.util.*;


public class Main {

    public static void main(String[] args) {
        String s1 = null;
        String s2 = null;
        String s3 = null;
        int f = 0;
        int d = 0;
        int g = 0;
	    Scanner scan = new Scanner(System.in);
	    do{
	    System.out.println("Inserisci il tuo nome:");
	    s1 = scan.nextLine();
	    if (s1.equals("")){
	        f = 1;
	        System.out.println("Devi inserire il dato obbligatoriamente.");
	    }
	    else{f = 0;}
	    }while(f == 1);
	    do{
	    System.out.println("Inserisci il tuo cognome:");
	    s2 = scan.nextLine();
	    if (s2.equals("")){
	        d = 1;
	       System.out.println("Devi inserire il dato obbligatoriamente.");
	       }else{d = 0;}
	    }while(d == 1);
	    do{
	    System.out.println("Inserisci la tua lingua: IT/EN/FR/DE/ES");
	    s3 = scan.nextLine();
	    if (s3.equals("")){
	       g = 1;
	       System.out.println("Devi inserire il dato obbligatoriamente.");
	       }else {g = 0;}
	    }while(g == 1);
	    if (s3.equals("IT")){
	        System.out.println("Benvenuto "+s1+" "+s2);
	    }else if (s3.equals("EN")){
	        System.out.println("Welcome "+s1+" "+s2);
	    }else if (s3.equals("FR")){
	        System.out.println("Vienvenue "+s1+" "+s2);
	    }else if (s3.equals("DE")){
	        System.out.println("Willkommen "+s1+" "+s2);
	    }else if (s3.equals("ES")){
	        System.out.println("Bienvenida "+s1+" "+s2);
	    }else{System.out.println("Il sistema non parla questa lingua.");
	    }
	    }
	    }