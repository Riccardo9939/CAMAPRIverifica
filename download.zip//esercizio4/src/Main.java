import java.util.Scanner;




public class Main {
    public static void main(String[] args) {
	   
	    Scanner scan = new Scanner(System.in);
	  
	    System.out.println("inserisci il tuo nome");
	     String a = scan.nextLine();
	     
	     System.out.println("inserisci il tuo cognome");
	     String b = scan.nextLine();
	    
	     
	        
	     
	     
	    
	    System.out.println("BUONGIORNO" + " " + a +  " " + b);
	    scan.close();
    }
    
    }


