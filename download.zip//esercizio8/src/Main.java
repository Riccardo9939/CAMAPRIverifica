import java.util.*;
import java.io.*;

public class Main {

    public static void main(String[] args) {
           Scanner scan = new Scanner(System.in);
           String s1=null;
           String s2=null;
           String s3=null;
            System.out.println("Inserisci il tuo nome:");
            s1 = scan.nextLine();
            System.out.println("Inserisci il tuo cognome:");
            s2 = scan.nextLine();
            System.out.println("Inserisci la tua lingua: IT/EN/FR/DE/ES");
            s3 = scan.nextLine();
            if (s1.equals("") || s2.equals("") || s3.equals(""))
            {
                 System.out.print("Manca ");
                 if (s1.equals("")){
                     System.out.print("il nome  "); 
                 }
                 if (s2.equals("")){
                     System.out.print("il cognome  "); 
                 }
                
                if (s3.equals("")){
                     System.out.println("la lingua  "); 
                 }
                
            }else {
                if (s3.equals("IT")){
                    System.out.println("Benvenuto "+s1+" "+s2);
                }else if (s3.equals("EN")){
                    System.out.println("Welcome "+s1+" "+s2);
                }else if (s3.equals("FR")){
                    System.out.println("Bienvenue "+s1+" "+s2);
                }else if (s3.equals("DE")){
                    System.out.println("Willkommen "+s1+" "+s2);
                }else if (s3.equals("ES")){
                    System.out.println("Bienvenida "+s1+" "+s2);
                }
                else{
                    System.out.println("Non parllo la tua lingua");
                }
            }   
    }
}