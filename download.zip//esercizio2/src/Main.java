import java.util.Scanner;



public class Main {
    public static void main(String[] args) {
	   
	    Scanner scan = new Scanner(System.in);
	    
	    System.out.println("Numero da elevare!");
	     int a = scan.nextInt();
	     System.out.println("inserisci la potenza");
	     int b = scan.nextInt();
	    double c = Math.pow (a, b);
	    System.out.println("il riusltato è!" + c);
	    scan.close();
    }

}
