import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
	   
	    Scanner scan = new Scanner(System.in);
	  
	    System.out.println("inserisci il tuo nome");
	     String a = scan.nextLine();
	     
	     System.out.println("inserisci il tuo cognome");
	     String b = scan.nextLine();
	    
	    System.out.println("inserisci la lingua tra: inglese, francese, spagnolo, tedesco e italaino");
	    String c = scan.nextLine();
	    
	    if(c.equals("francese")){
	          System.out.println("BOUNJUR" + " " + a +  " " + b);
	    }
	       if(c.equals("inglese")){
	          System.out.println("HELLO" + " " + a +  " " + b);
	    }
	       if(c.equals("spagnolo")){
	          System.out.println("HOLA" + " " + a +  " " + b);
	    }
	      if(c.equals("tedesco")){
	        System.out.println("Gutemorgen" + " " + a +  " " + b);
	    }
	        if(c.equals("italiano")){  
	          System.out.println("CIAO" + " " + a +  " " + b);
	    }
	    scan.close();
    }
    
    }
